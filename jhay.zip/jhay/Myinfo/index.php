<?php include_once('connect.php'); ?>

<html>
<title> Profile </title>
<body bgcolor="Blue";>
<h1><center> Profile</h1></center>
<button><a class="btn btn--pill btn--green" type="submit" href="../index.php">logout</a></button>
<h2 style="background-color:lightblue;"> <strong> Personal Data </h2>

<td>Name:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td><br>
</tr>
<td>Last Name:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td><br>
</tr>
<td>M.I:</td>
<td><input type="text" name="textnames" id="textname" size="10"></td>
</tr>
<tr>
				<td>Postal Address:</td>
		<td><input type="text" name="paddress" id="paddress" size="30"></td>
</tr>
<tr>
				<td>Personal Address:</td>
	<td><input type="text" name="personaladdress" id="personaladdress" size="30"></td>
</tr><br>

<tr>
<td>Sex</td>
<td> 		<input type="radio" name="sex" value="male" size="10">Male
		<input type="radio" name="sex" value="Female" size="10">Female</td>
</tr><br>
<td>City:</td>
<td><select name="City">
					<option value="-1" selected="">select..</option>
				<option value="Zamboanga City">Zamboanga</option>
			<option value="Zamboanga Del Sur">Pagadian</option>
		<option value="Zamboanga Del Norte">Davao</option>
	<option value="Zamboanga Del Norte">Cebu</option>
</select></td>
</tr><br>
<tr>
<td>Provincial Address:</td>
<td><select name="City">
						<option value="-1" selected="">select..</option>
			<option value="Zamboanga City">ZAMBOANGA CITY</option>
			<option value="Zamboanga Del Sur">ZAMBOANGA DEL SUR</option>
		<option value="Zamboanga Del Norte">ZAMBOANGA DEL NORTE</option>
</select></td>
</tr><br>

<tr>
<td>Course</td>
<td><select name="Course">
	<option value="-1" selected="">select..</option>
	<option value="BSIT">BACHELOR SCIENCE IN INFORMATION TECHNOLOGY</option>
	<option value="BSBA">BACHELOR SCIENCE IN BUSINESS ADMINISTRATION</option>
	<option value="BSN">BACHELOR OF SCIENCE IN NURSING</option>
	<option value="BSMT">BACHELOR OF SCIENCE IN MARINE TRANSPORTATION</option>
</select></td><br>
</tr>
<tr>
		<td>Student Id</td>
		<td><input type="text" name="text" id="text" size="30"></td>
</tr>
<tr>
	<td>Email:</td>
	<td><input type="text" name="emailid" id="emailid" size="30"></td>
</tr>
	<td>LRN:</td>
	<td><input type="text" name="text" id="text" size="20"></td>
	</tr><br>
<tr>
		<td>Mobile No.:</td>
		<td><input type="text" name="mobileno" id="mobileno" size="20"></td>
		</tr><br><br>
<h2 style="background-color:lightgrey;">FAMILY DATA</h2><br>
<td>Father's Name:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td>
 <td>Occupation:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td><br>
</tr>
<td>Mother's Name:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td>
</tr>
<td>Occupation:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td>
</tr><br>
<tr>
		<td>No. of Brothers</td>
		<td><input type="text" name="text" id="text" size="5"></td>
</tr>
<tr>
		<td>No. of Sister's</td>
		<td><input type="text" name="text" id="text" size="5"></td>
</tr> <br>
<td>Residential Tel No.:</td>
<td><input type="text" name="textnames" id="textname" size="20"></td>
</tr><br>
<tr>
		<td>Occupation:</td>
		<td><input type="text" name="text" id="text" size="15"></td>
</tr>
<tr>
		<td>	No. of Children:</td>
		<td><input type="text" name="text" id="text" size="5"></td>
</tr
<tr>
		<td>	Social Status:</td>
		<td><input type="text" name="text" id="text" size="15"></td>
</tr <br>
<br>

<h2 style="background-color:lightgrey;">PERSON TO BE NOTIFIED IN CASE OF EMERGENCY</h2><br>
<td>Guardian's Name:</td>
<td><input type="text" name="textnames" id="textname" size="30"></td>
</tr><br>
<td>Relationship:</td>
<td><input type="text" name="textnames" id="textname" size="20"></td>
</tr><br>
<td>Guardian's Tel No.:</td>
<td><input type="text" name="textnames" id="textname" size="20"></td>
</tr><br>
<td> Guardian's Cell No.:</td>
<td><input type="text" name="textnames" id="textname" size="20"></td>
</tr><br>
<td> Guardian's Address:</td>
<td><input type="text" name="textnames" id="textname" size="50"></td>
</tr><br>
<h2 style="background-color:lightgrey;"> EDUCATIONAL DATA</h2>
<br>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>


<table style="width:100%">
  <tr>
    <th>School Level</th>
    <th>Name of School</th>
  </tr>
  <tr>
    <td><tr>
<td>Elementary</td>
<td><select name="Course">
	<option value="-1" selected="">select..</option>
	<option value="Spes">Sias Pilot Elementary School</option>
	<option value="Spest">siasi pilot Elementary School</option>
	<option value="Tcs">tetuan central School</option>
	<option value="Mcs">Siasi pilot School</option>
</select></td>
</tr></td>
    <td>Junior High School</td>
    <td><select name="Course">
	<option value="-1" selected="">select..</option>
	<option value="NDS">Notre dame of siasi </option>
	<option value="MHS">MSU High School</option>
	<option value="SNHS">Notre dame of jolo</option>
	<option value="SCC">southern city collage
		